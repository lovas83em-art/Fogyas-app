package hu.fogyas.koveto.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM goal WHERE id = 1")
    fun getGoal(): Flow<Goal?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: Goal)

    @Query("SELECT * FROM daily_entry ORDER BY date DESC")
    fun getAllEntries(): Flow<List<DailyEntry>>

    @Query("SELECT * FROM daily_entry WHERE date = :date")
    suspend fun getEntry(date: String): DailyEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: DailyEntry)

    @Query("SELECT * FROM daily_entry WHERE date >= :from AND date <= :to")
    suspend fun getEntriesBetween(from: String, to: String): List<DailyEntry>
}
