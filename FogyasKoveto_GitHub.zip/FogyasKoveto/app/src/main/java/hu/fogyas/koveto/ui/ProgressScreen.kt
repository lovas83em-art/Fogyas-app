package hu.fogyas.koveto.ui

import android.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun ProgressScreen(vm: MainViewModel) {
    val entries by vm.allEntries.collectAsState()
    val goal by vm.goal.collectAsState()
    val summary = vm.weeklySummary(goal, entries)

    val weightEntries = remember(entries) {
        entries
            .filter { it.weight != null }
            .sortedBy { it.date }
    }

    Column(
        Modifier
            .padding(16.dp)
            .fillMaxSize()
    ) {
        Text("Haladás & heti összesítő", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        // Heti összesítő
        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "Ezen a héten: ${summary.total} / ${summary.target} perc",
                    style = MaterialTheme.typography.titleMedium
                )
                Text("Séta: ${summary.walk} perc")
                Text("Crosstrainer: ${summary.cross} perc")
                Text("Bicikli: ${summary.bike} perc")
                Text("Hátralévő: ${summary.remaining} perc")
                LinearProgressIndicator(
                    progress = { (summary.total.toFloat() / summary.target).coerceAtMost(1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // Súlygrafikon
        Text("Testsúly grafikon", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        if (weightEntries.size >= 2) {
            Card(
                Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                AndroidView(
                    factory = { context ->
                        LineChart(context).apply {
                            description.isEnabled = false
                            setTouchEnabled(true)
                            isDragEnabled = true
                            setScaleEnabled(true)
                            setPinchZoom(true)
                            legend.isEnabled = false
                            xAxis.position = XAxis.XAxisPosition.BOTTOM
                            xAxis.granularity = 1f
                            xAxis.setDrawGridLines(false)
                            axisRight.isEnabled = false
                            axisLeft.setDrawGridLines(true)
                        }
                    },
                    update = { chart ->
                        val entriesList = weightEntries.mapIndexed { index, e ->
                            Entry(index.toFloat(), e.weight!!)
                        }

                        val dataSet = LineDataSet(entriesList, "Testsúly").apply {
                            color = Color.parseColor("#4CAF50")
                            setCircleColor(Color.parseColor("#2E7D32"))
                            lineWidth = 2.5f
                            circleRadius = 4f
                            setDrawValues(true)
                            valueTextSize = 10f
                            mode = LineDataSet.Mode.CUBIC_BEZIER
                        }

                        chart.data = LineData(dataSet)

                        val labels = weightEntries.map {
                            LocalDate.parse(it.date)
                                .format(DateTimeFormatter.ofPattern("MM.dd"))
                        }
                        chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
                        chart.xAxis.labelCount = minOf(6, labels.size)

                        chart.invalidate()
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                )
            }
        } else {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Legalább 2 súlybejegyzés szükséges a grafikonhoz.\nÍrd be a súlyodat a Főoldalon!",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Utolsó bejegyzések", style = MaterialTheme.typography.titleMedium)

        LazyColumn {
            items(entries.take(20)) { entry ->
                ListItem(
                    headlineContent = { Text(entry.date) },
                    supportingContent = {
                        Text(
                            "Súly: ${entry.weight?.let { "%.1f".format(it) } ?: "–"} kg  |  " +
                                    "Mozgás: ${entry.totalExercise} perc"
                        )
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
