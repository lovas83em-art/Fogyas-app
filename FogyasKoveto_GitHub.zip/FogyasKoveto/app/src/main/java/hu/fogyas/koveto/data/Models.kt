package hu.fogyas.koveto.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "goal")
data class Goal(
    @PrimaryKey val id: Int = 1,
    val userName: String = "",
    val startWeight: Float,
    val targetWeight: Float,
    val targetDate: String,          // yyyy-MM-dd
    val weeklyExerciseGoal: Int = 300 // perc
)

@Entity(tableName = "daily_entry")
data class DailyEntry(
    @PrimaryKey val date: String,    // yyyy-MM-dd
    val weight: Float? = null,
    val walkMinutes: Int = 0,
    val crosstrainerMinutes: Int = 0,
    val bikeMinutes: Int = 0
) {
    val totalExercise: Int
        get() = walkMinutes + crosstrainerMinutes + bikeMinutes
}
