package hu.fogyas.koveto.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(vm: MainViewModel) {
    val goal by vm.goal.collectAsState()
    val entries by vm.allEntries.collectAsState()
    val todayEntry = entries.find { it.date == vm.today }

    var weightText by remember { mutableStateOf(todayEntry?.weight?.toString() ?: "") }

    Column(
        Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Személyre szabott köszönés
        val name = goal?.userName?.takeIf { it.isNotBlank() }
        Text(
            text = if (name != null) "Szia, $name!" else "Szia!",
            style = MaterialTheme.typography.headlineSmall
        )

        Text(
            "Mai nap – ${LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy. MM. dd."))}",
            style = MaterialTheme.typography.titleMedium
        )

        OutlinedTextField(
            value = weightText,
            onValueChange = { weightText = it },
            label = { Text("Testsúly (kg)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Button(
            onClick = { weightText.toFloatOrNull()?.let { vm.saveWeight(it) } },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Súly mentése")
        }

        goal?.let { g ->
            val current = todayEntry?.weight
                ?: entries.firstOrNull { it.weight != null }?.weight

            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Haladás", style = MaterialTheme.typography.titleMedium)
                    Text("Kezdő: ${g.startWeight} kg  →  Cél: ${g.targetWeight} kg")
                    Text("Jelenlegi: ${current?.let { "%.1f".format(it) } ?: "–"} kg")
                    Text("Hátralévő: ${"%.1f".format(vm.remainingKg(current, g))} kg")
                    Text("Haladás: ${vm.progressPercent(current, g)} %")
                    Text("Hátralévő napok: ${vm.daysLeft(g)}")
                    LinearProgressIndicator(
                        progress = { vm.progressPercent(current, g) / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        } ?: run {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Állíts be célt és a nevedet a „Cél” fülön!",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        val summary = vm.weeklySummary(goal, entries)
        Card(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("Heti mozgás", style = MaterialTheme.typography.titleMedium)
                Text("${summary.total} / ${summary.target} perc")
                Text("Séta: ${summary.walk} perc")
                Text("Crosstrainer: ${summary.cross} perc")
                Text("Bicikli: ${summary.bike} perc")
                Text("Hátralévő: ${summary.remaining} perc")
                LinearProgressIndicator(
                    progress = { (summary.total.toFloat() / summary.target).coerceAtMost(1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
            }
        }
    }
}
