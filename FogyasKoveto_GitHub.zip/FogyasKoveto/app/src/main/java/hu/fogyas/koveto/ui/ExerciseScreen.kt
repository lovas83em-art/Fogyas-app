package hu.fogyas.koveto.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun ExerciseScreen(vm: MainViewModel) {
    val entries by vm.allEntries.collectAsState()
    val goal by vm.goal.collectAsState()
    val todayEntry = entries.find { it.date == vm.today }

    var walk by remember { mutableStateOf(todayEntry?.walkMinutes?.toString() ?: "0") }
    var cross by remember { mutableStateOf(todayEntry?.crosstrainerMinutes?.toString() ?: "0") }
    var bike by remember { mutableStateOf(todayEntry?.bikeMinutes?.toString() ?: "0") }

    val dailyTarget = vm.dynamicDailyGoal(goal, entries)

    Column(
        Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Napi mozgás", style = MaterialTheme.typography.titleLarge)
        Text(
            "Mai dinamikus cél: $dailyTarget perc",
            style = MaterialTheme.typography.titleMedium
        )

        OutlinedTextField(
            value = walk,
            onValueChange = { walk = it },
            label = { Text("Séta (perc)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = cross,
            onValueChange = { cross = it },
            label = { Text("Crosstrainer (perc)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = bike,
            onValueChange = { bike = it },
            label = { Text("Bicikli (perc)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(
            onClick = {
                vm.saveExercise(
                    walk.toIntOrNull() ?: 0,
                    cross.toIntOrNull() ?: 0,
                    bike.toIntOrNull() ?: 0
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Mozgás mentése")
        }

        val totalToday = (walk.toIntOrNull() ?: 0) +
                (cross.toIntOrNull() ?: 0) +
                (bike.toIntOrNull() ?: 0)
        Text("Mai összesen: $totalToday perc", style = MaterialTheme.typography.bodyLarge)
    }
}
