package hu.fogyas.koveto.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun GoalScreen(vm: MainViewModel) {
    val goal by vm.goal.collectAsState()

    var userName by remember { mutableStateOf(goal?.userName ?: "") }
    var start by remember { mutableStateOf(goal?.startWeight?.toString() ?: "") }
    var target by remember { mutableStateOf(goal?.targetWeight?.toString() ?: "") }
    var date by remember {
        mutableStateOf(goal?.targetDate ?: LocalDate.now().plusMonths(3).toString())
    }
    var weekly by remember { mutableStateOf(goal?.weeklyExerciseGoal?.toString() ?: "300") }

    LaunchedEffect(goal) {
        goal?.let {
            userName = it.userName
            start = it.startWeight.toString()
            target = it.targetWeight.toString()
            date = it.targetDate
            weekly = it.weeklyExerciseGoal.toString()
        }
    }

    Column(
        Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Cél beállítása", style = MaterialTheme.typography.titleLarge)

        OutlinedTextField(
            value = userName,
            onValueChange = { userName = it },
            label = { Text("A neved") },
            placeholder = { Text("pl. Anna") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        OutlinedTextField(
            value = start,
            onValueChange = { start = it },
            label = { Text("Kezdő testsúly (kg)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = target,
            onValueChange = { target = it },
            label = { Text("Cél testsúly (kg)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Céldátum (yyyy-MM-dd)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        OutlinedTextField(
            value = weekly,
            onValueChange = { weekly = it },
            label = { Text("Heti mozgáscél (perc)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(
            onClick = {
                val s = start.toFloatOrNull()
                val t = target.toFloatOrNull()
                val w = weekly.toIntOrNull() ?: 300
                if (s != null && t != null) {
                    vm.saveGoal(userName, s, t, date, w)
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Cél mentése")
        }

        if (goal != null) {
            Text(
                "Beállítások elmentve.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
