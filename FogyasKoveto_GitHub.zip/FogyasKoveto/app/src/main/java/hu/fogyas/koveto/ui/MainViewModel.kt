package hu.fogyas.koveto.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import hu.fogyas.koveto.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import kotlin.math.max
import kotlin.math.roundToInt

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val formatter = DateTimeFormatter.ISO_LOCAL_DATE

    val goal = dao.getGoal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val allEntries = dao.getAllEntries().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val today = LocalDate.now().format(formatter)

    fun saveGoal(
        userName: String,
        start: Float,
        target: Float,
        date: String,
        weeklyGoal: Int
    ) {
        viewModelScope.launch {
            dao.insertGoal(
                Goal(
                    userName = userName.trim(),
                    startWeight = start,
                    targetWeight = target,
                    targetDate = date,
                    weeklyExerciseGoal = weeklyGoal
                )
            )
        }
    }

    fun saveWeight(weight: Float) {
        viewModelScope.launch {
            val existing = dao.getEntry(today) ?: DailyEntry(today)
            dao.insertEntry(existing.copy(weight = weight))
        }
    }

    fun saveExercise(walk: Int, cross: Int, bike: Int) {
        viewModelScope.launch {
            val existing = dao.getEntry(today) ?: DailyEntry(today)
            dao.insertEntry(
                existing.copy(
                    walkMinutes = walk,
                    crosstrainerMinutes = cross,
                    bikeMinutes = bike
                )
            )
        }
    }

    fun remainingKg(currentWeight: Float?, goal: Goal?): Float {
        if (currentWeight == null || goal == null) return 0f
        return max(0f, currentWeight - goal.targetWeight)
    }

    fun progressPercent(currentWeight: Float?, goal: Goal?): Int {
        if (currentWeight == null || goal == null) return 0
        val total = goal.startWeight - goal.targetWeight
        if (total <= 0) return 100
        val lost = goal.startWeight - currentWeight
        return ((lost / total) * 100).roundToInt().coerceIn(0, 100)
    }

    fun daysLeft(goal: Goal?): Long {
        if (goal == null) return 0
        val target = LocalDate.parse(goal.targetDate)
        return ChronoUnit.DAYS.between(LocalDate.now(), target).coerceAtLeast(0)
    }

    fun dynamicDailyGoal(goal: Goal?, entries: List<DailyEntry>): Int {
        if (goal == null) return 0
        val weekStart = LocalDate.now().with(java.time.DayOfWeek.MONDAY)
        val weekEntries = entries.filter {
            val d = LocalDate.parse(it.date)
            !d.isBefore(weekStart) && !d.isAfter(LocalDate.now())
        }
        val done = weekEntries.sumOf { it.totalExercise }
        val remainingDays = 7 - LocalDate.now().dayOfWeek.value + 1
        val remaining = (goal.weeklyExerciseGoal - done).coerceAtLeast(0)
        return if (remainingDays > 0) (remaining / remainingDays.toFloat()).roundToInt() else 0
    }

    fun weeklySummary(goal: Goal?, entries: List<DailyEntry>): WeeklySummary {
        val weekStart = LocalDate.now().with(java.time.DayOfWeek.MONDAY)
        val weekEntries = entries.filter {
            val d = LocalDate.parse(it.date)
            !d.isBefore(weekStart)
        }
        val walk = weekEntries.sumOf { it.walkMinutes }
        val cross = weekEntries.sumOf { it.crosstrainerMinutes }
        val bike = weekEntries.sumOf { it.bikeMinutes }
        val total = walk + cross + bike
        val target = goal?.weeklyExerciseGoal ?: 300
        return WeeklySummary(
            total = total,
            target = target,
            walk = walk,
            cross = cross,
            bike = bike,
            remaining = (target - total).coerceAtLeast(0)
        )
    }
}

data class WeeklySummary(
    val total: Int,
    val target: Int,
    val walk: Int,
    val cross: Int,
    val bike: Int,
    val remaining: Int
)
