# FogyasKoveto

Ez a csomag a rendelkezésre álló Android/Gradle projektfájlokat tartalmazza.

Megjegyzés: a kapott eredeti ZIP nem tartalmazta az Android alkalmazás forráskódját
(pl. `app/src/main/...`), ezért ezek nélkül az alkalmazás teljes projektje nem állítható
helyre kitalálás nélkül.

GitHubra feltöltéshez a `FogyasKoveto` mappa teljes tartalmát töltsd fel a repository gyökerébe.
