# FogyásKövető – Android app

Egyszerű, gyors fogyás- és mozgáskövető alkalmazás Kotlin + Jetpack Compose + Room alapokon.

## Funkciók

1. **Cél beállítása** – kezdő súly, cél súly, céldátum, heti mozgáscél
2. **Napi testsúly** – rögzítés, hátralévő kg, haladás %
3. **Napi mozgás** – séta / crosstrainer / bicikli (perc)
4. **Heti mozgáscél** + dinamikus napi cél (automatikusan újraszámol)
5. **Haladás** – súlygrafikon, heti összesítő, utolsó bejegyzések

## Telepítés / Build

1. Nyisd meg a projektet **Android Studio** (Hedgehog vagy újabb) segítségével.
2. Várj a Gradle sync-re.
3. Csatlakoztass egy telefont vagy indíts emulátort.
4. Nyomd meg a zöld Run gombot, vagy:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. Az elkészült `app-debug.apk` a  
   `app/build/outputs/apk/debug/` mappában lesz.

### Release APK (aláírt)
Build → Generate Signed Bundle / APK → APK → Create new keystore → Finish.

## Minimum követelmények
- Android 8.0 (API 26)+
- Android Studio Ladybug / Hedgehog vagy újabb

Készült 2025-ben.
